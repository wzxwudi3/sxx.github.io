import { useRef, useEffect, useMemo } from 'react'
import * as THREE from 'three'

interface ParticleFieldProps {
  className?: string
}

export default function ParticleField({ className }: ParticleFieldProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const frameRef = useRef<number>(0)

  const particleCount = useMemo(() => 8000, [])

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const scene = new THREE.Scene()
    scene.fog = new THREE.FogExp2(0x000000, 0.02)

    const camera = new THREE.PerspectiveCamera(60, container.clientWidth / container.clientHeight, 0.1, 100)
    camera.position.set(0, 2, 8)
    camera.lookAt(0, 0, 0)

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false })
    renderer.setSize(container.clientWidth, container.clientHeight)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.setClearColor(0x000000, 1)
    renderer.domElement.style.width = '100%'
    renderer.domElement.style.height = '100%'
    renderer.domElement.style.display = 'block'
    container.appendChild(renderer.domElement)
    rendererRef.current = renderer

    // Particles
    const geometry = new THREE.BufferGeometry()
    const positions = new Float32Array(particleCount * 3)
    const colors = new Float32Array(particleCount * 3)
    const sizes = new Float32Array(particleCount)
    const randoms = new Float32Array(particleCount * 3)
    const lifetimes = new Float32Array(particleCount)

    const accentColor = new THREE.Color('#ff3b30')
    const whiteColor = new THREE.Color('#ffffff')
    const tempColor = new THREE.Color()

    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3
      const angle = Math.random() * Math.PI * 2
      const radius = 0.5 + Math.random() * 6
      const height = (Math.random() - 0.5) * 3

      positions[i3] = Math.cos(angle) * radius
      positions[i3 + 1] = height
      positions[i3 + 2] = Math.sin(angle) * radius

      const t = Math.random()
      tempColor.copy(whiteColor).lerp(accentColor, t * t)
      colors[i3] = tempColor.r
      colors[i3 + 1] = tempColor.g
      colors[i3 + 2] = tempColor.b

      sizes[i] = 0.5 + Math.random() * 2.5
      lifetimes[i] = Math.random()

      randoms[i3] = Math.random()
      randoms[i3 + 1] = Math.random()
      randoms[i3 + 2] = Math.random()
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3))
    geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1))
    geometry.setAttribute('random', new THREE.BufferAttribute(randoms, 3))
    geometry.setAttribute('lifetime', new THREE.BufferAttribute(lifetimes, 1))

    const vertexShader = `
      attribute float size;
      attribute vec3 random;
      attribute float lifetime;
      varying vec3 vColor;
      varying float vAlpha;
      uniform float uTime;

      vec3 rot3d(vec3 axis, float angle, vec3 v) {
        float s = sin(angle);
        float c = cos(angle);
        return v * c + cross(axis, v) * s + axis * dot(axis, v) * (1.0 - c);
      }

      void main() {
        vColor = color;
        float t = uTime * 0.15;
        float lt = mod(lifetime + t * 0.3, 1.0);

        vec3 pos = position;
        float dist = length(pos.xz);

        // Spiral rotation
        float spiralAngle = pow(dist, 0.25) - t * 0.75;
        vec3 yRotated = rot3d(vec3(0.0, 1.0, 0.0), 1.0, pos);
        vec3 twisted = rot3d(vec3(0.0, 1.0, 0.0), spiralAngle, yRotated);

        float spiralFactor = pow(dist, 0.25) * 0.3;
        vec3 spiralDir = normalize(cross(twisted, vec3(0.0, 1.0, 0.0))) * spiralFactor;

        vec3 finalPos = twisted - spiralDir;

        // Gravity fall
        vec3 gravity = vec3(0.0, -0.7, 0.0);
        vec3 falling = gravity * lt * lt * lt;
        finalPos += falling;

        // Fade out near end
        float fadeOut = smoothstep(0.75, 1.0, lt);
        finalPos = mix(finalPos, vec3(0.0), fadeOut);

        // Add some noise movement
        finalPos.x += sin(t * random.x * 2.0 + random.y * 10.0) * 0.05;
        finalPos.y += cos(t * random.z * 2.0 + random.x * 10.0) * 0.05;
        finalPos.z += sin(t * random.y * 2.0 + random.z * 10.0) * 0.05;

        vec4 mvPosition = modelViewMatrix * vec4(finalPos, 1.0);
        gl_Position = projectionMatrix * mvPosition;
        gl_PointSize = size * (300.0 / -mvPosition.z);

        // Alpha based on lifetime
        vAlpha = 1.0 - fadeOut;
        // Fade based on distance from center
        float centerFade = smoothstep(0.0, 0.5, dist);
        vAlpha *= centerFade;
      }
    `

    const fragmentShader = `
      varying vec3 vColor;
      varying float vAlpha;

      void main() {
        float dist = length(gl_PointCoord - vec2(0.5));
        if (dist > 0.5) discard;
        float glow = 1.0 - smoothstep(0.0, 0.5, dist);
        glow = pow(glow, 1.5);
        gl_FragColor = vec4(vColor, vAlpha * glow);
      }
    `

    const material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms: {
        uTime: { value: 0 },
      },
      transparent: true,
      depthWrite: false,
      vertexColors: true,
      blending: THREE.AdditiveBlending,
    })

    const points = new THREE.Points(geometry, material)
    scene.add(points)

    // Add some ambient light glow
    const ambientLight = new THREE.AmbientLight(0x000000)
    scene.add(ambientLight)

    const startTime = performance.now()

    const animate = () => {
      frameRef.current = requestAnimationFrame(animate)
      const elapsed = (performance.now() - startTime) / 1000
      material.uniforms.uTime.value = elapsed

      // Slowly rotate the camera
      camera.position.x = Math.sin(elapsed * 0.05) * 8
      camera.position.z = Math.cos(elapsed * 0.05) * 8
      camera.lookAt(0, 0, 0)

      renderer.render(scene, camera)
    }

    animate()

    const onResize = () => {
      if (!container) return
      const w = container.clientWidth
      const h = container.clientHeight
      camera.aspect = w / h
      camera.updateProjectionMatrix()
      renderer.setSize(w, h)
    }

    window.addEventListener('resize', onResize)

    return () => {
      window.removeEventListener('resize', onResize)
      cancelAnimationFrame(frameRef.current)
      renderer.dispose()
      geometry.dispose()
      material.dispose()
      if (container && renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement)
      }
      rendererRef.current = null
    }
  }, [particleCount])

  return (
    <div
      ref={containerRef}
      className={className}
      style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 1 }}
    />
  )
}
