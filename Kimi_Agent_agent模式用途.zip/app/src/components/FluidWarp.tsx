import { useRef, useEffect, useCallback } from 'react'

interface FluidWarpProps {
  children: React.ReactNode
  className?: string
}

interface FluidState {
  mouseX: number
  mouseY: number
  mouseLerpedX: number
  mouseLerpedY: number
  mouseSpeed: number
  mouseDirectionX: number
  mouseDirectionY: number
  scrollSpeed: number
  firstFrame: boolean
  forceStop: boolean
  prevMouseX: number
  prevMouseY: number
  prevTime: number
  clearColor: { r: number; g: number; b: number }
}

export default function FluidWarp({ children, className }: FluidWarpProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fluidRef = useRef<FluidState>({
    mouseX: -1,
    mouseY: -1,
    mouseLerpedX: -1,
    mouseLerpedY: -1,
    mouseSpeed: 0,
    mouseDirectionX: 0,
    mouseDirectionY: 0,
    scrollSpeed: 0,
    firstFrame: true,
    forceStop: false,
    prevMouseX: -1,
    prevMouseY: -1,
    prevTime: 0,
    clearColor: { r: 0.95, g: 0.95, b: 0.95 },
  })
  const frameRef = useRef<number>(0)
  const textureRef = useRef<HTMLImageElement | null>(null)

  useEffect(() => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.src = '/texture-abstract.jpg'
    textureRef.current = img
  }, [])

  const getWebGLCoordinate = useCallback((clientX: number, clientY: number, element: HTMLElement) => {
    const rect = element.getBoundingClientRect()
    const x = 2.0 * (clientX - rect.left) / rect.width - 1.0
    const y = -(2.0 * (clientY - rect.top) / rect.height - 1.0)
    return { x, y, rectWidth: rect.width, rectHeight: rect.height }
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const sizeX = Math.floor(window.innerWidth / 4)
    const sizeY = Math.floor(window.innerHeight / 4)
    canvas.width = sizeX
    canvas.height = sizeY

    // Offscreen canvas for fluid simulation
    const fluidCanvas = document.createElement('canvas')
    fluidCanvas.width = sizeX
    fluidCanvas.height = sizeY
    const fluidCtx = fluidCanvas.getContext('2d')
    if (!fluidCtx) return

    // Second offscreen canvas for splats
    const splatCanvas = document.createElement('canvas')
    splatCanvas.width = sizeX
    splatCanvas.height = sizeY
    const splatCtx = splatCanvas.getContext('2d')
    if (!splatCtx) return

    // Third offscreen for display
    const displayCanvas = document.createElement('canvas')
    displayCanvas.width = sizeX
    displayCanvas.height = sizeY
    const displayCtx = displayCanvas.getContext('2d')
    if (!displayCtx) return

    const scaleConfig = {
      splatRadius: 1.1,
      velocityScale: 0.4,
      velocityOffsetScale: 1.5,
    }

    const fluid = fluidRef.current

    const splat = (
      sx: number, sy: number,
      dx: number, dy: number,
      rx: number, ry: number,
      color: { r: number; g: number; b: number }
    ) => {
      const grad = splatCtx.createRadialGradient(
        (sx * 0.5 + 0.5) * sizeX,
        (-sy * 0.5 + 0.5) * sizeY,
        0,
        (sx * 0.5 + 0.5) * sizeX,
        (-sy * 0.5 + 0.5) * sizeY,
        Math.max(rx * sizeX, ry * sizeY) * 3
      )
      const a = Math.min(0.3, 0.1 + Math.sqrt(dx * dx + dy * dy) * 0.5)
      grad.addColorStop(0, `rgba(${Math.round(color.r * 255)}, ${Math.round(color.g * 255)}, ${Math.round(color.b * 255)}, ${a})`)
      grad.addColorStop(1, `rgba(${Math.round(color.r * 255)}, ${Math.round(color.g * 255)}, ${Math.round(color.b * 255)}, 0)`)

      splatCtx.fillStyle = grad
      splatCtx.fillRect(0, 0, sizeX, sizeY)
    }

    const display = (texture: CanvasImageSource) => {
      displayCtx.clearRect(0, 0, sizeX, sizeY)
      displayCtx.drawImage(texture, 0, 0, sizeX, sizeY)
    }

    const renderFluidLoop = () => {
      const mouseX = fluid.mouseLerpedX
      const mouseY = fluid.mouseLerpedY
      const mouseSpeed = fluid.mouseSpeed
      const mouseDirection = { x: fluid.mouseDirectionX, y: fluid.mouseDirectionY }

      // Clear splat canvas each frame with fade
      splatCtx.fillStyle = 'rgba(255, 255, 255, 0.02)'
      splatCtx.fillRect(0, 0, sizeX, sizeY)

      // Apply fade to fluid canvas
      fluidCtx.fillStyle = 'rgba(245, 245, 245, 0.05)'
      fluidCtx.fillRect(0, 0, sizeX, sizeY)

      if (fluid.firstFrame) {
        splat(-1, -1, 0, 0, 0.1, 0.1, fluid.clearColor)
        display(splatCanvas)
        fluid.firstFrame = false
        return
      }

      if (mouseX < 0 || mouseY < 0 || fluid.forceStop) {
        return
      }

      const aspectX = sizeY / sizeX
      const aspectY = 1.0

      const velocityScale = scaleConfig.velocityScale
      const dx = mouseDirection.x * mouseSpeed * velocityScale * aspectX
      const dy = mouseDirection.y * mouseSpeed * velocityScale * aspectY

      // Crimson color
      const color = { r: 1.0, g: 0.1, b: 0.1 }

      // Main crimson splat
      const scale = scaleConfig.splatRadius * 0.1
      splat(mouseX, mouseY, dx, dy, scale * aspectX, scale * aspectY, color)
      display(splatCanvas)

      // White fog offset
      if (mouseSpeed > 0.00001) {
        const offsetScale = scaleConfig.velocityOffsetScale
        splat(
          mouseX + mouseDirection.x * 0.01,
          mouseY + mouseDirection.y * 0.01,
          -mouseDirection.x * mouseSpeed * offsetScale * aspectX,
          -mouseDirection.y * mouseSpeed * offsetScale * aspectY,
          scale * aspectX,
          scale * aspectY,
          fluid.clearColor
        )
      }

      // Draw splat into fluid
      fluidCtx.drawImage(splatCanvas, 0, 0, sizeX, sizeY)

      // Draw texture if loaded
      if (textureRef.current && textureRef.current.complete) {
        displayCtx.globalAlpha = 0.08
        displayCtx.drawImage(textureRef.current, 0, 0, sizeX, sizeY)
        displayCtx.globalAlpha = 1.0
      }
    }

    const animate = () => {
      frameRef.current = requestAnimationFrame(animate)

      // Lerp mouse position
      if (fluid.mouseX >= 0 && fluid.mouseY >= 0) {
        if (fluid.mouseLerpedX < 0) {
          fluid.mouseLerpedX = fluid.mouseX
          fluid.mouseLerpedY = fluid.mouseY
        }
        fluid.mouseLerpedX += (fluid.mouseX - fluid.mouseLerpedX) * 0.15
        fluid.mouseLerpedY += (fluid.mouseY - fluid.mouseLerpedY) * 0.15
      }

      // Decay scroll speed
      fluid.scrollSpeed *= 0.95

      // Decay mouse speed
      fluid.mouseSpeed *= 0.9

      renderFluidLoop()

      // Render to visible canvas
      ctx.clearRect(0, 0, sizeX, sizeY)
      ctx.drawImage(fluidCanvas, 0, 0, sizeX, sizeY)
    }

    animate()

    const onMouseMove = (e: MouseEvent) => {
      const coords = getWebGLCoordinate(e.clientX, e.clientY, container)
      fluid.mouseX = coords.x
      fluid.mouseY = coords.y

      // Calculate speed and direction
      if (fluid.prevMouseX >= 0) {
        const dt = Math.max(performance.now() - fluid.prevTime, 1) / 1000
        const ddx = coords.x - fluid.prevMouseX
        const ddy = coords.y - fluid.prevMouseY
        const dist = Math.sqrt(ddx * ddx + ddy * ddy)
        fluid.mouseSpeed = Math.min(dist / Math.max(dt, 0.001), 2.0)
        if (dist > 0.0001) {
          fluid.mouseDirectionX = ddx / dist
          fluid.mouseDirectionY = ddy / dist
        }
      }
      fluid.prevMouseX = coords.x
      fluid.prevMouseY = coords.y
      fluid.prevTime = performance.now()
    }

    const onMouseLeave = () => {
      fluid.mouseX = -1
      fluid.mouseY = -1
      fluid.mouseLerpedX = -1
      fluid.mouseLerpedY = -1
      fluid.mouseSpeed = 0
    }

    const onScroll = () => {
      fluid.scrollSpeed = Math.min(Math.abs(window.scrollY) * 0.001, 1.0)
    }

    container.addEventListener('mousemove', onMouseMove)
    container.addEventListener('mouseleave', onMouseLeave)
    window.addEventListener('scroll', onScroll, { passive: true })

    const onResize = () => {
      const newSizeX = Math.floor(window.innerWidth / 4)
      const newSizeY = Math.floor(window.innerHeight / 4)
      canvas.width = newSizeX
      canvas.height = newSizeY
      fluidCanvas.width = newSizeX
      fluidCanvas.height = newSizeY
      splatCanvas.width = newSizeX
      splatCanvas.height = newSizeY
      displayCanvas.width = newSizeX
      displayCanvas.height = newSizeY
    }

    window.addEventListener('resize', onResize)

    return () => {
      cancelAnimationFrame(frameRef.current)
      container.removeEventListener('mousemove', onMouseMove)
      container.removeEventListener('mouseleave', onMouseLeave)
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onResize)
    }
  }, [getWebGLCoordinate])

  return (
    <div ref={containerRef} className={`relative ${className || ''}`}>
      <canvas
        ref={canvasRef}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          zIndex: 0,
          opacity: 0.15,
          pointerEvents: 'none',
          mixBlendMode: 'multiply',
          filter: 'blur(2px)',
        }}
      />
      <div className="relative z-10">{children}</div>
    </div>
  )
}
