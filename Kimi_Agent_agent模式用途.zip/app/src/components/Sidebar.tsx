import { useEffect, useState, useRef } from 'react'
import gsap from 'gsap'

interface SidebarProps {
  onNavigate: (section: string) => void
  activeSection: string
}

export default function Sidebar({ onNavigate, activeSection }: SidebarProps) {
  const [time, setTime] = useState('')
  const sidebarRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      const h = String(now.getHours()).padStart(2, '0')
      const m = String(now.getMinutes()).padStart(2, '0')
      const s = String(now.getSeconds()).padStart(2, '0')
      setTime(`${h}:${m}:${s}`)
    }
    updateTime()
    const interval = setInterval(updateTime, 1000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (!sidebarRef.current) return
    gsap.fromTo(
      sidebarRef.current,
      { opacity: 0, x: -30 },
      { opacity: 1, x: 0, duration: 1.2, delay: 0.5, ease: 'power3.out' }
    )
  }, [])

  const navItems = [
    { id: 'hero', label: 'Home' },
    { id: 'journal', label: 'Articles' },
    { id: 'about', label: 'About' },
  ]

  return (
    <div
      ref={sidebarRef}
      className="fixed left-0 top-0 h-full w-[240px] z-50 flex flex-col justify-between py-12 px-8"
      style={{ opacity: 0 }}
    >
      {/* Top: Logo area */}
      <div>
        <div className="font-mono text-xs tracking-widest text-[#888888] mb-1">PORTFOLIO</div>
        <div className="text-2xl font-bold tracking-tight text-white">陈默</div>
        <div className="font-mono text-xs text-[#888888] mt-1">CHEN MO</div>

        {/* Divider */}
        <div className="w-full h-px bg-white/15 mt-8 mb-8" />

        {/* Navigation */}
        <nav className="flex flex-col gap-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`text-left py-2 px-0 font-mono text-sm tracking-wider transition-colors duration-300 ${
                activeSection === item.id ? 'text-white' : 'text-[#888888] hover:text-white'
              }`}
              data-cursor-hover
            >
              <span className="text-[#ff3b30] mr-3 text-xs">
                {activeSection === item.id ? '●' : '○'}
              </span>
              {item.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Bottom: Info */}
      <div>
        {/* Bio */}
        <p className="text-xs text-[#888888] leading-relaxed mb-8 font-light" style={{ fontFamily: "'Noto Sans SC', sans-serif" }}>
          独立撰稿人，专注技术人文观察与建筑摄影。常驻上海与东京。
        </p>

        <div className="w-full h-px bg-white/15 mb-6" />

        {/* Status */}
        <div className="flex items-center gap-3">
          <span
            className="inline-block w-2 h-2 rounded-full bg-[#ff3b30]"
            style={{ animation: 'pulse 2s ease-in-out infinite' }}
          />
          <span className="font-mono text-xs text-[#888888]">ONLINE</span>
        </div>
        <div className="font-mono text-xs text-[#888888] mt-2 tracking-wider">{time}</div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.3; }
        }
      `}</style>
    </div>
  )
}
