import { useEffect, useRef, useState, useCallback } from 'react'
import Lenis from 'lenis'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import CustomCursor from './components/CustomCursor'
import Sidebar from './components/Sidebar'
import HeroStage from './sections/HeroStage'
import JournalFeed from './sections/JournalFeed'
import AboutSection from './sections/AboutSection'
import Footer from './sections/Footer'

gsap.registerPlugin(ScrollTrigger)

function App() {
  const [activeSection, setActiveSection] = useState('hero')
  const lenisRef = useRef<Lenis | null>(null)

  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      touchMultiplier: 2,
    })
    lenisRef.current = lenis

    lenis.on('scroll', ScrollTrigger.update)

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000)
    })
    gsap.ticker.lagSmoothing(0)

    // Section detection
    const sections = ['hero', 'journal', 'about']
    sections.forEach((id) => {
      const el = document.getElementById(id)
      if (!el) return
      ScrollTrigger.create({
        trigger: el,
        start: 'top center',
        end: 'bottom center',
        onEnter: () => setActiveSection(id),
        onEnterBack: () => setActiveSection(id),
      })
    })

    return () => {
      lenis.destroy()
      ScrollTrigger.getAll().forEach((t) => t.kill())
    }
  }, [])

  const handleNavigate = useCallback((section: string) => {
    const el = document.getElementById(section)
    if (el && lenisRef.current) {
      lenisRef.current.scrollTo(el, { offset: 0 })
    }
  }, [])

  return (
    <div className="relative">
      <CustomCursor />
      <Sidebar onNavigate={handleNavigate} activeSection={activeSection} />

      <main className="relative">
        <HeroStage />
        <JournalFeed />
        <AboutSection />
        <Footer />
      </main>
    </div>
  )
}

export default App
