export default function Footer() {
  return (
    <footer className="relative bg-black border-t border-white/15">
      <div className="py-12" style={{ paddingLeft: '280px', paddingRight: '60px' }}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <p
              className="text-xs text-[#888888] font-mono tracking-wider"
              style={{ lineHeight: 2 }}
            >
              Designed & Coded by Chen Mo. Powered by Chaos.
            </p>
            <p className="text-[10px] text-[#555555] font-mono tracking-wider mt-1">
              &copy; {new Date().getFullYear()} CHEN MO. ALL RIGHTS RESERVED.
            </p>
          </div>

          <div className="flex items-center gap-6">
            {['Twitter', 'Instagram', 'GitHub'].map((platform) => (
              <a
                key={platform}
                href="#"
                className="text-xs font-mono tracking-wider text-[#888888] hover:text-[#ff3b30] transition-colors duration-300"
                data-cursor-hover
              >
                {platform.toUpperCase()}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
