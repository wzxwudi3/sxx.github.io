import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const imageRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)
  const statsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (imageRef.current) {
        gsap.fromTo(
          imageRef.current,
          { opacity: 0, x: -40 },
          {
            opacity: 1,
            x: 0,
            duration: 1.2,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: imageRef.current,
              start: 'top 80%',
              toggleActions: 'play none none none',
            },
          }
        )
      }

      if (textRef.current) {
        gsap.fromTo(
          textRef.current,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: textRef.current,
              start: 'top 80%',
              toggleActions: 'play none none none',
            },
          }
        )
      }

      if (statsRef.current) {
        gsap.fromTo(
          statsRef.current,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: statsRef.current,
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
          }
        )
      }
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  const stats = [
    { number: '8+', label: '年写作经历' },
    { number: '120+', label: '发表文章' },
    { number: '2', label: '常驻城市' },
    { number: '∞', label: '好奇心' },
  ]

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative bg-black"
      style={{ minHeight: '100vh' }}
    >
      <div className="py-24 md:py-32" style={{ paddingLeft: '280px', paddingRight: '60px' }}>
        {/* Section Header */}
        <div className="mb-16 md:mb-24">
          <div className="flex items-baseline gap-6 mb-4">
            <span className="font-mono text-xs text-[#888888] tracking-[0.3em]">ABOUT</span>
            <div className="flex-1 h-px bg-white/15" />
          </div>
          <h2
            className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-white"
            style={{ fontFamily: "'Noto Sans SC', sans-serif", lineHeight: 1.1 }}
          >
            关于
          </h2>
          <p
            className="font-display italic text-2xl md:text-3xl text-[#888888] mt-3"
            style={{ fontWeight: 400 }}
          >
            The Person Behind the Words
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          {/* Image */}
          <div ref={imageRef} className="relative" style={{ opacity: 0 }}>
            <div className="relative overflow-hidden aspect-[3/4] max-w-md">
              <img
                src="/avatar.jpg"
                alt="陈默"
                className="w-full h-full object-cover"
                style={{ filter: 'grayscale(100%) contrast(1.1)' }}
              />
              {/* Overlay accent line */}
              <div className="absolute bottom-0 left-0 w-full h-1 bg-[#ff3b30]" />
            </div>
            <div className="mt-6 font-mono text-xs text-[#888888] tracking-wider">
              SHANGHAI, 2024
            </div>
          </div>

          {/* Text */}
          <div ref={textRef} style={{ opacity: 0 }}>
            <div className="space-y-6 text-[#aaaaaa] text-sm md:text-base leading-relaxed font-light" style={{ fontFamily: "'Noto Sans SC', sans-serif", lineHeight: 2 }}>
              <p>
                我是陈默，一个用文字和镜头记录世界的独立撰稿人。我的写作横跨技术人文、建筑摄影与城市观察三个领域，试图在看似 unrelated 的事物之间建立联系。
              </p>
              <p>
                毕业于同济大学建筑系，但我选择了一条不同的路——不设计房子，而是描述房子与人之间的关系。我相信好的文字应该像好的建筑一样：有结构、有光影、有让人停留的空间。
              </p>
              <p>
                这个博客是我思考的痕迹。从东京的混凝土教堂到上海正在消逝的弄堂，从 AI 的情感可能性到无屏幕生活的实验——我写的，是那些让我深夜睡不着的问题。
              </p>
              <p className="text-white">
                如果你也对这些话题感兴趣，欢迎通过邮件与我交流。
              </p>
            </div>

            {/* CTA */}
            <div className="mt-10">
              <a
                href="mailto:hello@chenmo.blog"
                className="inline-flex items-center gap-3 text-sm font-mono tracking-wider text-white hover:text-[#ff3b30] transition-colors duration-300"
                data-cursor-hover
              >
                <span className="w-8 h-px bg-current" />
                HELLO@CHENMO.BLOG
              </a>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div
          ref={statsRef}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-24 pt-16 border-t border-white/15"
          style={{ opacity: 0 }}
        >
          {stats.map((stat) => (
            <div key={stat.label}>
              <div className="text-3xl md:text-4xl font-bold text-white tracking-tight">{stat.number}</div>
              <div className="font-mono text-xs text-[#888888] mt-2 tracking-wider">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
