import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import FluidWarp from '../components/FluidWarp'

gsap.registerPlugin(ScrollTrigger)

interface Article {
  year: string
  title: string
  titleEn: string
  tag: string
  date: string
}

const articles: Article[] = [
  { year: '2026', title: '东京代代木：混凝土中的时间感', titleEn: 'Yoyogi, Tokyo: Time in Concrete', tag: '#建筑摄影', date: '2026.05' },
  { year: '2026', title: '算法的诗意：当 AI 学会悲伤', titleEn: 'The Poetry of Algorithms', tag: '#技术人文', date: '2026.03' },
  { year: '2025', title: '上海弄堂的黄昏与消逝', titleEn: 'Shanghai Lanes at Dusk', tag: '#城市观察', date: '2025.11' },
  { year: '2025', title: '无屏幕生活的三十天实验', titleEn: 'Thirty Days Without Screens', tag: '#生活方式', date: '2025.08' },
  { year: '2025', title: '安藤忠雄的光之教堂笔记', titleEn: 'Ando\'s Church of Light Notes', tag: '#建筑摄影', date: '2025.05' },
  { year: '2024', title: '京都枯山水：静止中的流动', titleEn: 'Kyoto Zen Gardens', tag: '#建筑摄影', date: '2024.12' },
  { year: '2024', title: '代码即媒介：编程语言的美学', titleEn: 'Code as Medium', tag: '#技术人文', date: '2024.09' },
  { year: '2024', title: '深夜食堂：食物背后的社会学', titleEn: 'Midnight Diner Sociology', tag: '#城市观察', date: '2024.06' },
  { year: '2024', title: '极简主义工具箱的幻觉', titleEn: 'The Minimalist Toolkit Illusion', tag: '#生活方式', date: '2024.03' },
  { year: '2023', title: '东京站大饭店：时间的层积', titleEn: 'Tokyo Station Hotel', tag: '#建筑摄影', date: '2023.11' },
]

function ArticleRow({ article, index }: { article: Article; index: number }) {
  const rowRef = useRef<HTMLDivElement>(null)
  const [isHovered, setIsHovered] = useState(false)

  useEffect(() => {
    if (!rowRef.current) return
    gsap.fromTo(
      rowRef.current,
      { opacity: 0, y: 30 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        delay: index * 0.06,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: rowRef.current,
          start: 'top 90%',
          toggleActions: 'play none none none',
        },
      }
    )
  }, [index])

  return (
    <div
      ref={rowRef}
      className="group border-b border-black/10 transition-colors duration-500"
      style={{
        opacity: 0,
        backgroundColor: isHovered ? 'rgba(255, 59, 48, 0.03)' : 'transparent',
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      data-cursor-hover
    >
      <div className="flex items-baseline py-6 px-4 md:px-8 gap-6 md:gap-12">
        {/* Year */}
        <div
          className="font-mono text-sm md:text-base flex-shrink-0 w-16 transition-colors duration-300"
          style={{
            color: isHovered ? '#ff3b30' : '#888888',
            fontVariantNumeric: 'tabular-nums',
          }}
        >
          {article.year}
        </div>

        {/* Title */}
        <div className="flex-1 min-w-0">
          <div
            className="text-base md:text-lg font-medium tracking-tight truncate transition-colors duration-300"
            style={{
              color: isHovered ? '#ff3b30' : '#111111',
              fontFamily: "'Noto Sans SC', sans-serif",
            }}
          >
            {article.title}
          </div>
          <div
            className="text-xs md:text-sm mt-1 truncate transition-colors duration-300"
            style={{
              color: isHovered ? 'rgba(255, 59, 48, 0.5)' : '#aaaaaa',
              fontFamily: "'Playfair Display', serif",
              fontStyle: 'italic',
            }}
          >
            {article.titleEn}
          </div>
        </div>

        {/* Date */}
        <div
          className="font-mono text-xs flex-shrink-0 hidden sm:block w-20 text-right transition-colors duration-300"
          style={{ color: isHovered ? '#ff3b30' : '#cccccc' }}
        >
          {article.date}
        </div>

        {/* Tag */}
        <div
          className="font-mono text-xs flex-shrink-0 hidden md:block w-24 text-right transition-colors duration-300"
          style={{
            color: isHovered ? '#ff3b30' : '#888888',
          }}
        >
          {article.tag}
        </div>
      </div>
    </div>
  )
}

export default function JournalFeed() {
  const sectionRef = useRef<HTMLElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!headerRef.current) return
    gsap.fromTo(
      headerRef.current,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: headerRef.current,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      }
    )
  }, [])

  return (
    <section
      id="journal"
      ref={sectionRef}
      className="relative bg-white"
      style={{ minHeight: '100vh' }}
    >
      <FluidWarp className="w-full h-full">
        <div className="py-24 md:py-32" style={{ paddingLeft: '280px', paddingRight: '60px' }}>
          {/* Section Header */}
          <div ref={headerRef} className="mb-16 md:mb-24" style={{ opacity: 0 }}>
            <div className="flex items-baseline gap-6 mb-4">
              <span className="font-mono text-xs text-[#888888] tracking-[0.3em]">JOURNAL</span>
              <div className="flex-1 h-px bg-black/10" />
            </div>
            <h2
              className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-black"
              style={{ fontFamily: "'Noto Sans SC', sans-serif", lineHeight: 1.1 }}
            >
              文章日志
            </h2>
            <p
              className="font-display italic text-2xl md:text-3xl text-[#888888] mt-3"
              style={{ fontWeight: 400 }}
            >
              Selected Writings
            </p>
          </div>

          {/* Articles List */}
          <div className="border-t border-black/10">
            {articles.map((article, index) => (
              <ArticleRow key={`${article.title}-${index}`} article={article} index={index} />
            ))}
          </div>
        </div>
      </FluidWarp>
    </section>
  )
}
