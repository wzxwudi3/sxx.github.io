import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import ParticleField from '../components/ParticleField'

export default function HeroStage() {
  const titleRef = useRef<HTMLDivElement>(null)
  const subtitleRef = useRef<HTMLDivElement>(null)
  const scrollIndicatorRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const tl = gsap.timeline({ delay: 0.8 })

    if (titleRef.current) {
      tl.fromTo(
        titleRef.current,
        { opacity: 0, y: 40 },
        { opacity: 1, y: 0, duration: 1.4, ease: 'power3.out' }
      )
    }

    if (subtitleRef.current) {
      tl.fromTo(
        subtitleRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 1, ease: 'power3.out' },
        '-=0.8'
      )
    }

    if (scrollIndicatorRef.current) {
      tl.fromTo(
        scrollIndicatorRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 0.8, ease: 'power2.out' },
        '-=0.3'
      )
    }

    return () => { tl.kill() }
  }, [])

  return (
    <section
      id="hero"
      className="relative w-full min-h-screen bg-black overflow-hidden"
    >
      {/* Particle Background */}
      <ParticleField />

      {/* Content overlay */}
      <div className="absolute inset-0 z-10 flex flex-col justify-center" style={{ paddingLeft: '280px', paddingRight: '60px' }}>
        <div ref={titleRef} style={{ opacity: 0 }}>
          <h1
            className="font-display text-white leading-none tracking-tight"
            style={{
              fontSize: 'clamp(3rem, 8vw, 7rem)',
              fontWeight: 400,
              fontStyle: 'italic',
              letterSpacing: '-0.02em',
              lineHeight: 1.05,
            }}
          >
            OBSERVE THE
            <br />
            INVISIBLE
          </h1>
          <p
            className="text-white/60 mt-4 font-light tracking-wide"
            style={{
              fontSize: 'clamp(0.875rem, 1.2vw, 1.125rem)',
              fontFamily: "'Noto Sans SC', sans-serif",
              letterSpacing: '0.15em',
            }}
          >
            观察不可见之物
          </p>
        </div>

        <div ref={subtitleRef} className="mt-16 max-w-lg" style={{ opacity: 0 }}>
          <p
            className="text-[#888888] text-sm leading-relaxed font-light"
            style={{ fontFamily: "'Noto Sans SC', sans-serif", lineHeight: 2 }}
          >
            在这个被信息淹没的时代，真正的洞察往往隐藏在表象之下。
            <br />
            用文字与镜头，记录那些容易被忽略的瞬间与结构。
          </p>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        ref={scrollIndicatorRef}
        className="absolute bottom-12 z-10 flex flex-col items-center gap-3"
        style={{ left: '280px', opacity: 0 }}
      >
        <span className="font-mono text-[10px] tracking-[0.3em] text-[#888888]">SCROLL</span>
        <div className="w-px h-12 bg-gradient-to-b from-white/40 to-transparent" />
      </div>

      {/* Decorative elements */}
      <div className="absolute top-1/4 right-16 z-10 hidden lg:block">
        <div className="font-mono text-[10px] text-[#888888] tracking-widest" style={{ writingMode: 'vertical-rl' }}>
          EST. 2019 • SHANGHAI / TOKYO
        </div>
      </div>
    </section>
  )
}
